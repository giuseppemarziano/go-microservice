package event

// TODO define event after RabbitMQ implementation
