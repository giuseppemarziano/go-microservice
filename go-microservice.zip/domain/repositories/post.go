package repositories

type PostRepository interface {
	// TODO add post repository methods
}
