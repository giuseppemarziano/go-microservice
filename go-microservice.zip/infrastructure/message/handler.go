package message

// TODO implement rabbitmq for event handling
